/* Search + filtering for the home page and the two list pages */
const Search={
 match(c,s){
  if(s.cat&&s.cat!=='all'&&c.category.toLowerCase()!==s.cat)return false;
  const t=(c.brand+' '+c.name+' '+c.body).toLowerCase();
  if(s.q&&!s.q.toLowerCase().split(/\s+/).every(w=>t.includes(w)))return false;
  if(s.brands?.size&&!s.brands.has(c.brand))return false;
  if(s.fuels?.size&&!s.fuels.has(c.fuel))return false;
  if(s.trans?.size&&![...s.trans].some(x=>c.transmission.includes(x)))return false;
  if(s.bodies?.size&&!s.bodies.has(c.body))return false;
  if(s.max&&c.priceLakh>s.max)return false;return true},
 sort(a,k){return k==='plow'?a.sort((x,y)=>x.priceLakh-y.priceLakh):k==='phigh'?a.sort((x,y)=>y.priceLakh-x.priceLakh):k==='name'?a.sort((x,y)=>x.name.localeCompare(y.name)):a},
 grid(el,cars){el.innerHTML=cars.length?cars.map(c=>Cars.card(c)).join(''):'<p class="empty">No cars match your search. Try another name or reset the filters.</p>';Compare.sync()}};
async function initHome(){
 await Cars.load();const g=$('#grid'),s={cat:'all',q:''};let all=false;
 const FEAT=['mahindra-thar-roxx','tata-safari','bmw-x5','lamborghini-urus-se','porsche-911-gt3-rs'];
 function draw(){if(Cars.failed){g.innerHTML=ERR;return}
  if(!(all||s.cat!=='all'||s.q)){$('#rtitle').textContent='Featured Cars';Search.grid(g,FEAT.map(i=>Cars.get(i)).filter(Boolean));return}
  const r=Cars.list.filter(c=>Search.match(c,s));$('#rtitle').textContent=r.length+(r.length===1?' Car Found':' Cars Found');Search.grid(g,r)}
 $$('.tab').forEach(b=>b.onclick=()=>{s.cat=b.dataset.cat;all=false;$$('.tab').forEach(t=>t.classList.toggle('on',t===b));draw()});
 $('#q').oninput=()=>{s.q=$('#q').value.trim();draw()};
 $('#q').onkeydown=e=>{if(e.key==='Enter')$('#sbtn').click()};
 $('#sbtn').onclick=()=>{s.q=$('#q').value.trim();draw();$('#results').scrollIntoView()};
 $('#viewall').onclick=()=>{all=true;draw()};
 $$('.chip').forEach(c=>c.onclick=()=>{$('#q').value=s.q=c.dataset.brand;draw();$('#results').scrollIntoView()});
 if(location.hash==='#search')$('#q').focus();draw();
}
async function initListPage(){
 const cat=document.body.dataset.cat,nm=cat==='indian'?'Indian':'International',g=$('#grid');
 await Cars.load();if(Cars.failed){g.innerHTML=ERR;return}
 const base=Cars.list.filter(c=>c.category.toLowerCase()===cat),f=$('#filters');
 const s={cat,q:'',brands:new Set(),fuels:new Set(),trans:new Set(),bodies:new Set(),max:0};
 const lo=Math.floor(Math.min(...base.map(c=>c.priceLakh))),hi=Math.ceil(Math.max(...base.map(c=>c.priceLakh)));
 const uniq=p=>[...new Set(base.map(c=>c[p]))];
 const grp=(t,k,vals,cnt)=>`<div class="fg"><h4>${t}</h4>${vals.map(v=>`<label class="chk"><input type="checkbox" data-k="${k}" value="${esc(v)}">${esc(v)} (${cnt(v)})</label>`).join('')}</div>`;
 f.innerHTML=`<h3>Filter Cars</h3><input type="search" id="fq" placeholder="Search name or brand" aria-label="Search name or brand">`
  +grp('Brand','brands',uniq('brand'),v=>base.filter(c=>c.brand===v).length)
  +grp('Fuel Type','fuels',uniq('fuel'),v=>base.filter(c=>c.fuel===v).length)
  +grp('Transmission','trans',['Manual','Automatic'],v=>base.filter(c=>c.transmission.includes(v)).length)
  +grp('Body Type','bodies',uniq('body'),v=>base.filter(c=>c.body===v).length)
  +`<div class="fg"><h4>Price Range</h4><input type="range" id="maxp" min="${lo}" max="${hi}" value="${hi}" step="1" aria-label="Maximum price"><p id="pl"></p></div><div class="fa"><button class="btn red" id="apply">Apply Filter</button><button class="btn" id="reset">Reset</button></div>`;
 function run(){s.q=$('#fq').value.trim();['brands','fuels','trans','bodies'].forEach(k=>s[k]=new Set($$(`[data-k=${k}]:checked`,f).map(i=>i.value)));
  s.max=+$('#maxp').value;$('#pl').textContent='Up to ₹ '+Cars.fmt(s.max);
  const r=Search.sort(base.filter(c=>Search.match(c,s)),$('#sort').value);$('#count').textContent=r.length+' '+nm+' Cars Found';Search.grid(g,r)}
 f.oninput=run;$('#sort').onchange=run;$('#apply').onclick=()=>{run();g.scrollIntoView()};
 $('#reset').onclick=()=>{$$('input[type=checkbox]',f).forEach(i=>i.checked=false);$('#fq').value='';$('#maxp').value=hi;$('#sort').value='pop';run()};
 run();
}
