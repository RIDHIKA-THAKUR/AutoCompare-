/* Two-car comparison: localStorage store + compare page */
const Compare={key:'ac_compare',
 get(){try{return JSON.parse(localStorage.getItem(this.key))||[]}catch(e){return[]}},
 set(a){try{localStorage.setItem(this.key,JSON.stringify(a))}catch(e){}this.sync()},
 toggle(id){const a=this.get();
  if(a.includes(id)){this.set(a.filter(x=>x!==id));return toast('Removed from comparison.')}
  if(a.length>=2)return toast('Only two cars can be compared. Remove or replace one first.',true);
  a.push(id);this.set(a);toast(a.length===2?'Both cars selected.':'Added. Pick one more car to compare.',true)},
 sync(){const a=this.get();$$('[data-compare]').forEach(b=>{const on=a.includes(b.dataset.compare);b.classList.toggle('on',on);b.textContent=on?'Added ✓':(b.dataset.label||'Compare')})}};
document.addEventListener('click',e=>{const b=e.target.closest('[data-compare]');if(b)Compare.toggle(b.dataset.compare)});
async function comparePage(){
 await Cars.load();if(Cars.failed){$('#out').innerHTML=ERR;return}
 const A=$('#selA'),B=$('#selB'),opts='<option value="">Select a car</option>'+Cars.list.map(c=>`<option value="${c.id}">${esc(c.brand+' '+c.name)}</option>`).join('');
 A.innerHTML=B.innerHTML=opts;const st=Compare.get();A.value=st[0]||'';B.value=st[1]||'';
 let tab='specs';
 const head=(c,k)=>c?`<div class="head">${Cars.img(c)}<div><span class="brand">${esc(c.brand)}</span><h3>${esc(c.name)}</h3><p class="price">${Cars.price(c)}</p><div class="acts"><a class="btn outline" href="car-details.html?id=${c.id}">View Details</a><button class="btn ghost" data-rm="${k}">Remove</button></div></div></div>`:`<div class="head"><p>Select a ${k==='A'?'first':'second'} car above.</p></div>`;
 function render(){
  const a=Cars.get(A.value),b=Cars.get(B.value);
  Compare.set([a&&a.id,b&&b.id&&b.id!==(a&&a.id)?b.id:null].filter(Boolean));
  $$('.ctab').forEach(t=>t.classList.toggle('on',t.dataset.tab===tab));
  let h=`<div class="heads">${head(a,'A')}${head(b,'B')}</div>`;
  if(a&&b&&a.id===b.id)h+='<p class="empty">Choose two different cars to compare.</p>';
  else if(a&&b){
   const R={specs:[['Engine',c=>c.engine],['Fuel Type',c=>c.fuel],['Transmission',c=>c.transmission],['Mileage / Range',c=>c.mileage],['Seating Capacity',c=>c.seats],['Body Type',c=>c.body],['Price (ex-showroom)*',c=>Cars.price(c)]],
    features:[['Key Features',c=>`<ul>${c.features.map(f=>'<li>• '+esc(f)+'</li>').join('')}</ul>`]],
    price:[['Price*',c=>Cars.price(c)],['Difference',(c,o)=>c.priceLakh===o.priceLakh?'Same price':c.priceLakh<o.priceLakh?'₹ '+Cars.fmt(o.priceLakh-c.priceLakh)+' cheaper':'₹ '+Cars.fmt(c.priceLakh-o.priceLakh)+' costlier']]}[tab];
   h+=`<div class="scroll"><table class="cmp"><thead><tr><th>Specification</th><th>${esc(a.brand+' '+a.name)}</th><th>${esc(b.brand+' '+b.name)}</th></tr></thead><tbody>${R.map(([l,f])=>`<tr><td>${l}</td><td>${tab==='features'?f(a):esc(f(a,b))}</td><td>${tab==='features'?f(b):esc(f(b,a))}</td></tr>`).join('')}</tbody></table></div><p class="note">* Unverified sample data.</p>`}
  else h+=`<p class="empty">Select two cars to see them side by side, or use the Compare buttons on any car.<br><a class="btn red" href="index.html#results">Browse cars</a></p>`;
  $('#out').innerHTML=h}
 A.onchange=B.onchange=render;$('#go').onclick=()=>{if(!A.value||!B.value)toast('Select two cars first.');render();$('#out').scrollIntoView()};
 $('#swap').onclick=()=>{[A.value,B.value]=[B.value,A.value];render()};
 $('#clear').onclick=()=>{A.value=B.value='';render()};
 $$('.ctab').forEach(t=>t.onclick=()=>{tab=t.dataset.tab;render()});
 $('#out').onclick=e=>{const r=e.target.closest('[data-rm]');if(r){(r.dataset.rm==='A'?A:B).value='';render()}};
 render();
}
