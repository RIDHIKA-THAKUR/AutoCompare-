/* Car database loading, card rendering, details page */
const Cars={list:[],failed:false,
 async load(){if(this.list.length)return this.list;try{const r=await fetch('data/cars.json');if(!r.ok)throw 0;this.list=(await r.json()).cars}catch(e){this.failed=true}return this.list},
 get(id){return this.list.find(c=>c.id===id)},
 fmt(l){return l>=100?(l/100).toFixed(2)+' Crore':l.toFixed(2)+' Lakh'},
 price(c){return '₹ '+this.fmt(c.priceLakh)+'*'},
 ph(c){const t=esc(c.brand+' '+c.name);return 'data:image/svg+xml,'+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 250"><rect width="400" height="250" fill="#181818"/><path d="M60 150h280l-30-40H110z" fill="none" stroke="#e31b1b" stroke-width="4"/><circle cx="120" cy="155" r="18" fill="#333"/><circle cx="280" cy="155" r="18" fill="#333"/><text x="200" y="215" fill="#fff" font-size="20" text-anchor="middle" font-family="Arial">${t}</text></svg>`)},
 fb(img,id){img.onerror=null;img.src=this.ph(this.get(id))},
 img(c,i=0,cls=''){return `<img class="${cls}" src="${esc(c.images[i]||'')}" alt="${esc(c.brand+' '+c.name)}" loading="lazy" onerror="Cars.fb(this,'${c.id}')">`},
 card(c){const u='car-details.html?id='+encodeURIComponent(c.id);
  return `<article class="card"><a class="card-img" href="${u}">${this.img(c)}</a><div class="card-b"><span class="brand">${esc(c.brand)}</span><h3>${esc(c.name)}</h3><p class="price">${this.price(c)}</p><div class="acts"><a class="btn ghost" href="${u}">View Details</a><button class="btn outline" data-compare="${c.id}">Compare</button></div></div></article>`}
};
async function renderDetails(){
 await Cars.load();const id=new URLSearchParams(location.search).get('id'),c=Cars.get(id),el=$('#detail');
 if(!c){el.innerHTML=`<div class="empty"><h2>Car not found</h2><p>${Cars.failed?'Car data could not be loaded.':`No car with ID “${esc(id||'')}” exists.`}</p><a class="btn red" href="index.html">Browse all cars</a></div>`;return}
 document.title=c.brand+' '+c.name+' | AutoCompare';
 const rows=[['Engine',c.engine],['Fuel Type',c.fuel],['Transmission',c.transmission],['Mileage / Range',c.mileage],['Seating Capacity',c.seats],['Body Type',c.body]];
 el.innerHTML=`<div><img id="mainimg" class="main-img" alt="${esc(c.name)}" src="${esc(c.images[0])}" onerror="Cars.fb(this,'${c.id}')"><div class="thumbs">${c.images.map((s,i)=>Cars.img(c,i)).join('')}</div></div>
 <div><p class="crumb"><a href="index.html">Home</a> › <a href="${c.category==='Indian'?'indian':'international'}-cars.html">${c.category} Cars</a> › ${esc(c.name)}</p><span class="brand">${esc(c.brand)}</span><h1>${esc(c.name)}</h1><p class="price">${Cars.price(c)}</p><p>${esc(c.description)}</p>
 <div class="specs">${rows.map(r=>`<div class="spec"><small>${r[0]}</small>${esc(r[1])}</div>`).join('')}</div>
 <h2>Key Features</h2><ul class="feat">${c.features.map(f=>`<li>${esc(f)}</li>`).join('')}</ul>
 <div class="acts" style="margin-top:18px"><button class="btn red" data-compare="${c.id}" data-label="Add to Compare">Add to Compare</button><a class="btn ghost" href="compare-cars.html">Open Compare</a></div>
 <p class="note">* Unverified sample data. Confirm price and specifications with the manufacturer.</p></div>`;
 $$('.thumbs img').forEach(t=>t.onclick=()=>{$('#mainimg').src=t.src});
}
