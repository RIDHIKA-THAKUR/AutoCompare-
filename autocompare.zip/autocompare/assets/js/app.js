/* Shared helpers, header/footer, page dispatcher */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const ERR='<p class="empty">Car data could not be loaded. Open the site through a web server (GitHub Pages or <code>python -m http.server</code>), not by double-clicking the file.</p>';
const NAV=[['index.html','Home'],['indian-cars.html','Indian Cars'],['international-cars.html','International Cars'],['compare-cars.html','Compare Cars'],['about-us.html','About Us'],['contact-us.html','Contact Us']];
const LOGO='<a class="logo" href="index.html" aria-label="AutoCompare home"><svg width="44" height="22" viewBox="0 0 44 22" fill="none" stroke="#e31b1b" stroke-width="2" aria-hidden="true"><path d="M2 17h4m32 0h4M6 17c0-5 3-7 8-8l6-4h10l6 6c3 1 5 3 5 6"/><circle cx="14" cy="17" r="3"/><circle cx="34" cy="17" r="3"/></svg>Auto<b>Compare</b></a>';
const SVG=p=>`<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">${p}</svg>`;
function toast(msg,link){$('.toast')?.remove();const t=document.createElement('div');t.className='toast';t.setAttribute('role','status');t.innerHTML=`<span>${esc(msg)}</span>`+(link?'<a href="compare-cars.html">Open Compare</a>':'');document.body.append(t);setTimeout(()=>t.remove(),4500)}
function layout(){
  const cur=location.pathname.split('/').pop()||'index.html';
  $('#site-header').outerHTML=`<header class="site"><div class="wrap bar">${LOGO}<nav class="main" id="nav" aria-label="Main">${NAV.map(([h,t])=>`<a href="${h}"${h===cur?' class="on" aria-current="page"':''}>${t}</a>`).join('')}</nav><div class="right"><a class="icon-btn" href="index.html#search" aria-label="Search cars">${SVG('<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>')}</a><button class="icon-btn burger" id="burger" aria-label="Toggle menu" aria-expanded="false">${SVG('<path d="M3 6h18M3 12h18M3 18h18"/>')}</button></div></div></header>`;
  const L=(h,t)=>`<li><a href="${h}">${t}</a></li>`;
  $('#site-footer').outerHTML=`<footer class="site"><div class="wrap fgrid"><div>${LOGO}<p>Explore. Compare. Choose Your Dream Car.</p></div><div><h4>Quick Links</h4><ul>${L('index.html','Home')}${L('indian-cars.html','Indian Cars')}${L('international-cars.html','International Cars')}</ul></div><div><h4>More Links</h4><ul>${L('compare-cars.html','Compare Cars')}${L('about-us.html','About Us')}${L('contact-us.html','Contact Us')}</ul></div><div><h4>Follow Us</h4><div class="soc"><a href="https://www.youtube.com" target="_blank" rel="noopener" aria-label="YouTube">YT</a><a href="https://www.instagram.com" target="_blank" rel="noopener" aria-label="Instagram">IG</a><a href="https://www.facebook.com" target="_blank" rel="noopener" aria-label="Facebook">f</a><a href="https://www.linkedin.com" target="_blank" rel="noopener" aria-label="LinkedIn">in</a></div></div></div><p class="wrap copy">* Prices and specifications are unverified sample data. Check the manufacturer before buying.</p></footer>`;
  $('#burger').onclick=e=>{const o=$('#nav').classList.toggle('open');e.currentTarget.setAttribute('aria-expanded',o)};
}
document.addEventListener('DOMContentLoaded',()=>{layout();
  ({home:initHome,list:initListPage,details:renderDetails,compare:comparePage,contact:initContact})[document.body.dataset.page]?.();
  Compare.sync()});
function initContact(){const f=$('#cform');f.onsubmit=e=>{e.preventDefault();const d=new FormData(f);
  const body=`Name: ${d.get('name')}\nEmail: ${d.get('email')}\nPhone: ${d.get('phone')||'-'}\n\n${d.get('msg')}`;
  $('#status').textContent='Opening your email app to send the message…';
  location.href=`mailto:support@autocompare.in?subject=${encodeURIComponent('AutoCompare: '+d.get('topic'))}&body=${encodeURIComponent(body)}`}}
